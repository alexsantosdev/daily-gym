# Configuracao de integracao Strava

## Visão geral

Esta página foi gerada a partir de comportamento observado com Playwright. O conteúdo descreve evidências coletadas em execução automatizada e deve ser revisado quando a interface ou API mudar.

## Acesso e pré-requisitos

- Rotas observadas: `não observado`
- Papéis observados: `authenticated_user`

## Fluxos observados

### Consulta autenticada da configuracao de integracao

- Cenário: `api-strava-config-get`
- Rota: `/profile`
- Projeto Playwright: `chromium`
- Papel: `authenticated_user`
- Observação: Resposta registrada com status e estrutura de chaves do payload.

![Consulta autenticada da configuracao de integracao](../../assets/evidence/configuracao-de-integracao-strava/chromium--api-strava-config-get.png)

Evidência de API sanitizada: `artifacts/doc-guide/api-snippets/api-strava-config-get.json`

## Cenários negativos e validações

Quando aplicável, documente e mantenha evidências para campos obrigatórios, formatos inválidos, permissões insuficientes, sessão expirada, dados duplicados e valores limite.

## Troubleshooting

- Se a página redirecionar para login, revise o estado de autenticação usado na execução.
- Se as evidências não aparecerem, revise os caminhos de `static/evidence` ou `assets/evidence`.
- Se houver dados sensíveis nas imagens, bloqueie a publicação e ajuste as máscaras de captura.

## Manutenção

- Manifesto de evidências: `generated-user-guide\artifacts\doc-guide\manifest.jsonl`
- Atualize esta página sempre que rotas, rótulos, permissões ou contratos de API mudarem.

## Evidências de API

- `api-strava-config-get`: `artifacts/doc-guide/api-snippets/api-strava-config-get.json`
