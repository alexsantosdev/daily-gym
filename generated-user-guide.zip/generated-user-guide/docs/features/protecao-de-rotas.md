# Protecao de rotas

## Visão geral

Esta página foi gerada a partir de comportamento observado com Playwright. O conteúdo descreve evidências coletadas em execução automatizada e deve ser revisado quando a interface ou API mudar.

## Acesso e pré-requisitos

- Rotas observadas: `/calendar`
- Papéis observados: `anonymous`

## Fluxos observados

### Redirecionamento de visitante para login

- Cenário: `anonymous-redirect-calendar`
- Rota: `/calendar`
- Projeto Playwright: `chromium`
- Papel: `anonymous`
- Observação: Visitante sem sessao foi enviado para /login ao abrir rota protegida.

![Redirecionamento de visitante para login](../../assets/evidence/protecao-de-rotas/chromium--anonymous-redirect-calendar.png)

## Cenários negativos e validações

Quando aplicável, documente e mantenha evidências para campos obrigatórios, formatos inválidos, permissões insuficientes, sessão expirada, dados duplicados e valores limite.

## Troubleshooting

- Se a página redirecionar para login, revise o estado de autenticação usado na execução.
- Se as evidências não aparecerem, revise os caminhos de `static/evidence` ou `assets/evidence`.
- Se houver dados sensíveis nas imagens, bloqueie a publicação e ajuste as máscaras de captura.

## Manutenção

- Manifesto de evidências: `generated-user-guide\artifacts\doc-guide\manifest.jsonl`
- Atualize esta página sempre que rotas, rótulos, permissões ou contratos de API mudarem.
