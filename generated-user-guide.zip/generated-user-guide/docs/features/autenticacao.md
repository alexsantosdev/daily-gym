# Autenticacao

## Visão geral

Esta página foi gerada a partir de comportamento observado com Playwright. O conteúdo descreve evidências coletadas em execução automatizada e deve ser revisado quando a interface ou API mudar.

## Acesso e pré-requisitos

- Rotas observadas: `/login`
- Papéis observados: `anonymous`

## Fluxos observados

### Tela de entrada e campos obrigatorios

- Cenário: `login-view`
- Rota: `/login`
- Projeto Playwright: `chromium`
- Papel: `anonymous`
- Observação: Campos observados: E-mail, Senha, botoes de entrar e criar conta.

![Tela de entrada e campos obrigatorios](../../assets/evidence/autenticacao/chromium--login-view.png)

### Alternancia para modo de cadastro

- Cenário: `register-toggle`
- Rota: `/login`
- Projeto Playwright: `chromium`
- Papel: `anonymous`
- Observação: Modo de cadastro exibiu campo Nome e acao de criar conta.

![Alternancia para modo de cadastro](../../assets/evidence/autenticacao/chromium--register-toggle.png)

## Cenários negativos e validações

Quando aplicável, documente e mantenha evidências para campos obrigatórios, formatos inválidos, permissões insuficientes, sessão expirada, dados duplicados e valores limite.

## Troubleshooting

- Se a página redirecionar para login, revise o estado de autenticação usado na execução.
- Se as evidências não aparecerem, revise os caminhos de `static/evidence` ou `assets/evidence`.
- Se houver dados sensíveis nas imagens, bloqueie a publicação e ajuste as máscaras de captura.

## Manutenção

- Manifesto de evidências: `generated-user-guide\artifacts\doc-guide\manifest.jsonl`
- Atualize esta página sempre que rotas, rótulos, permissões ou contratos de API mudarem.
