# Navegacao autenticada

## Visão geral

Esta página foi gerada a partir de comportamento observado com Playwright. O conteúdo descreve evidências coletadas em execução automatizada e deve ser revisado quando a interface ou API mudar.

## Acesso e pré-requisitos

- Rotas observadas: `/calendar`, `/groups`, `/meals`, `/personal-ai`, `/reports`, `/water`, `/workouts`
- Papéis observados: `authenticated_user`

## Fluxos observados

### Acesso autenticado a /calendar

- Cenário: `auth-route-calendar`
- Rota: `/calendar`
- Projeto Playwright: `chromium`
- Papel: `authenticated_user`
- Observação: Rota carregou sem redirecionar para login.

![Acesso autenticado a /calendar](../../assets/evidence/navegacao-autenticada/chromium--auth-route-calendar.png)

### Acesso autenticado a /workouts

- Cenário: `auth-route-workouts`
- Rota: `/workouts`
- Projeto Playwright: `chromium`
- Papel: `authenticated_user`
- Observação: Rota carregou sem redirecionar para login.

![Acesso autenticado a /workouts](../../assets/evidence/navegacao-autenticada/chromium--auth-route-workouts.png)

### Acesso autenticado a /meals

- Cenário: `auth-route-meals`
- Rota: `/meals`
- Projeto Playwright: `chromium`
- Papel: `authenticated_user`
- Observação: Rota carregou sem redirecionar para login.

![Acesso autenticado a /meals](../../assets/evidence/navegacao-autenticada/chromium--auth-route-meals.png)

### Acesso autenticado a /reports

- Cenário: `auth-route-reports`
- Rota: `/reports`
- Projeto Playwright: `chromium`
- Papel: `authenticated_user`
- Observação: Rota carregou sem redirecionar para login.

![Acesso autenticado a /reports](../../assets/evidence/navegacao-autenticada/chromium--auth-route-reports.png)

### Acesso autenticado a /groups

- Cenário: `auth-route-groups`
- Rota: `/groups`
- Projeto Playwright: `chromium`
- Papel: `authenticated_user`
- Observação: Rota carregou sem redirecionar para login.

![Acesso autenticado a /groups](../../assets/evidence/navegacao-autenticada/chromium--auth-route-groups.png)

### Acesso autenticado a /water

- Cenário: `auth-route-water`
- Rota: `/water`
- Projeto Playwright: `chromium`
- Papel: `authenticated_user`
- Observação: Rota carregou sem redirecionar para login.

![Acesso autenticado a /water](../../assets/evidence/navegacao-autenticada/chromium--auth-route-water.png)

### Acesso autenticado a /personal-ai

- Cenário: `auth-route-personal-ai`
- Rota: `/personal-ai`
- Projeto Playwright: `chromium`
- Papel: `authenticated_user`
- Observação: Rota carregou sem redirecionar para login.

![Acesso autenticado a /personal-ai](../../assets/evidence/navegacao-autenticada/chromium--auth-route-personal-ai.png)

## Cenários negativos e validações

Quando aplicável, documente e mantenha evidências para campos obrigatórios, formatos inválidos, permissões insuficientes, sessão expirada, dados duplicados e valores limite.

## Troubleshooting

- Se a página redirecionar para login, revise o estado de autenticação usado na execução.
- Se as evidências não aparecerem, revise os caminhos de `static/evidence` ou `assets/evidence`.
- Se houver dados sensíveis nas imagens, bloqueie a publicação e ajuste as máscaras de captura.

## Manutenção

- Manifesto de evidências: `generated-user-guide\artifacts\doc-guide\manifest.jsonl`
- Atualize esta página sempre que rotas, rótulos, permissões ou contratos de API mudarem.
