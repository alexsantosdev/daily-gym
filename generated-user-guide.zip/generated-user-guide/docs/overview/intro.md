# Daily Gym - Guia do Usuario (evidencias Playwright)

## Objetivo

Este pacote documenta comportamentos observados da aplicacao web `daily-gym` com execucao real de navegador via Playwright. O foco desta versao e cobrir autenticacao, protecao de rotas e navegacao nas areas principais apos login.

## Escopo observado

- Base URL de execucao: valor de `E2E_BASE_URL` no arquivo `.env.e2e`.
- Perfil coberto: usuario autenticado com credenciais de E2E e visitante anonimo.
- Navegador usado para evidencia publicavel: projeto `chromium`.
- Areas documentadas:
- login e alternancia para cadastro;
- redirecionamento de rota protegida para `/login` sem sessao;
- acessos autenticados para `/calendar`, `/workouts`, `/meals`, `/reports`, `/groups`, `/water` e `/personal-ai`;
- chamada API `GET /api/strava/config` com snippet sanitizado.

## Onde estao as evidencias

- Manifesto principal: `generated-user-guide/artifacts/doc-guide/manifest.jsonl`.
- Capturas publicaveis: `generated-user-guide/assets/evidence/`.
- Snippet de API sanitizado: `generated-user-guide/artifacts/doc-guide/api-snippets/api-strava-config-get.json`.
- Paginas por feature: `generated-user-guide/docs/features/`.

## Regras de seguranca aplicadas

- Nenhuma credencial foi gravada em Markdown.
- Nenhum dado de sessao foi publicado.
- O snippet de API registra apenas verbo HTTP, rota, status e estrutura de chaves do corpo.

## Limitacoes desta rodada

- Cobertura visual feita apenas no projeto desktop `chromium`.
- Nao houve captura de fluxos de erro profundos por dominio (ex.: validacoes de formularios de treino, refeicao e grupos).
- Integracoes externas (como OAuth completo do Strava) nao foram executadas ponta a ponta nesta entrega.
