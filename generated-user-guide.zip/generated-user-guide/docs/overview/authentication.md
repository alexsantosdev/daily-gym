# Autenticacao e Acesso

## Entrada anonima

Comportamento observado na rota `/login`:

- Heading principal: `Entrar no daily-gym`.
- Campos exibidos: `E-mail` e `Senha`.
- Acoes visiveis: `Entrar` e `Criar nova conta`.
- Evidencia: `assets/evidence/autenticacao/chromium--login-view.png`.

## Alternancia para cadastro

Ao acionar `Criar nova conta`, a tela muda para modo de registro com:

- heading `Criar conta`;
- campo adicional `Nome`;
- acao de criacao de conta disponivel.

Evidencia: `assets/evidence/autenticacao/chromium--register-toggle.png`.

## Protecao de rotas sem sessao

Ao acessar `/calendar` sem sessao autenticada, houve redirecionamento para `/login`. Esse comportamento confirma guard de autenticacao para rota protegida.

Evidencia: `assets/evidence/protecao-de-rotas/chromium--anonymous-redirect-calendar.png`.

## Acesso autenticado observado

Depois do login com credenciais de `.env.e2e`, as rotas abaixo carregaram sem retorno para `/login`:

- `/calendar`
- `/workouts`
- `/meals`
- `/reports`
- `/groups`
- `/water`
- `/personal-ai`

As evidencias dessas rotas estao no diretorio `assets/evidence/navegacao-autenticada/`.

## Risco conhecido

As evidencias foram coletadas com um unico papel de usuario E2E. Permissoes por papeis adicionais (admin/suporte, caso existam) nao foram cobertas nesta rodada.
